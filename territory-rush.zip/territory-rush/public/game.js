(() => {
  const socket = typeof io === "function" ? io() : null;
  const $ = id => document.getElementById(id);
  const lobby = $("lobby"), roomPanel = $("roomPanel"), gamePanel = $("gamePanel");
  const canvas = $("gameCanvas"), ctx = canvas.getContext("2d");
  const SIZE = 40, CELL = canvas.width / SIZE;
  let room = null, localId = null, gameState = null, practice = false, local = null, bots = [], loop = null, toastTimer;
  const colors = ["#6c63ff", "#ff6b6b", "#2ec4b6", "#ffb703", "#f15bb5", "#4ea8de", "#80b918", "#fb8500"];
  const owned = (p, x, y) => p.territory?.includes(`${x},${y}`);
  function toast(msg) { const el=$("toast"); el.textContent=msg; el.classList.add("show"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),2600); }
  function name() { return $("playerName").value.trim() || "Player"; }
  function show(view) { [lobby,roomPanel,gamePanel].forEach(x=>x.classList.add("hidden")); view.classList.remove("hidden"); }
  function socketEmit(event, payload={}) { if (!socket) return toast("Multiplayer server unavailable. Start the server with npm start."); socket.emit(event,payload); }
  if (socket) {
    socket.on("connect",()=>{localId=socket.id;$("connection").textContent="Connected";$("connection").previousElementSibling.style.background="#30c784";socket.emit("rooms:refresh");});
    socket.on("disconnect",()=>{$("connection").textContent="Reconnecting";});
    socket.on("notice",toast);
    socket.on("rooms:list",renderRooms);
    socket.on("room:joined",r=>{room=r;show(roomPanel);renderRoom(r);});
    socket.on("room:update",r=>{room=r;renderRoom(r);});
    socket.on("game:start",data=>{room=data.room;gameState=data.state;practice=false;show(gamePanel);$("gameTitle").textContent=room.name;$("gameMode").textContent="MULTIPLAYER";$("gameOverlay").classList.add("hidden");});
    socket.on("game:state",s=>{gameState=s;});
    socket.on("game:over",s=>{gameState=s;const alive=Object.entries(s.players).filter(([id,p])=>p.alive);$("overlayTitle").textContent=alive[0]?.[0]===localId?"You own the arena!":"Match complete";$("overlayText").textContent=alive[0]?`${alive[0][1].name} wins the round.`:"Everyone was eliminated."; $("gameOverlay").classList.remove("hidden");});
  }
  function renderRooms(rooms) {
    const list=$("roomsList");
    if(!rooms?.length){list.innerHTML='<div class="empty">No open arenas yet. Create one and invite friends.</div>';return;}
    list.innerHTML=rooms.map(r=>`<div class="room-item"><div class="room-glyph">▦</div><div class="room-item-main"><strong>${esc(r.name)}</strong><small>${r.players}/${r.maxPlayers} players · ${r.code}</small></div><button class="btn btn-secondary" data-join="${r.code}">Join</button></div>`).join("");
    list.querySelectorAll("[data-join]").forEach(b=>b.onclick=()=>socketEmit("room:join",{code:b.dataset.join,name:name()}));
  }
  function renderRoom(r) {
    $("roomTitle").textContent=r.name;$("roomType").textContent=r.isPublic?"PUBLIC":"PRIVATE";$("currentCode").textContent=r.code;$("playerCount").textContent=`${r.players}/${r.maxPlayers}`;
    const host=r.hostId===localId;
    $("startBtn").classList.toggle("hidden",!host);$("readyBtn").classList.toggle("hidden",host);
    $("members").innerHTML=r.members.map((p,i)=>`<div class="member"><div class="avatar" style="background:${p.color}">${esc(p.name.slice(0,1).toUpperCase())}</div><div class="member-main"><strong>${esc(p.name)} ${p.id===r.hostId?"<small> · HOST</small>":""}</strong><small>${p.id===localId?"You are here":"Arena player"}</small></div><span class="status ${p.ready?"ready":""}">${p.ready?"✓ READY":"WAITING"}</span></div>`).join("");
    $("readyBtn").textContent=(r.members.find(p=>p.id===localId)?.ready?"↻ Not ready":"✓ I'm ready");
  }
  function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  $("createPrivate").onclick=()=>socketEmit("room:create",{name:name(),isPublic:false,roomName:`${name()}'s Arena`});
  $("createPublic").onclick=()=>socketEmit("room:create",{name:name(),isPublic:true,roomName:`${name()}'s Public Arena`});
  $("joinRoom").onclick=()=>socketEmit("room:join",{code:$("roomCode").value,name:name()});
  $("roomCode").addEventListener("keydown",e=>{if(e.key==="Enter")$("joinRoom").click();});
  $("quickJoin").onclick=()=>socketEmit("room:quick-join",{name:name()});
  $("refreshRooms").onclick=()=>socketEmit("rooms:refresh");
  $("readyBtn").onclick=()=>{const p=room?.members.find(p=>p.id===localId);socketEmit("room:ready",!p?.ready);};
  $("startBtn").onclick=()=>socketEmit("room:start");
  $("leaveRoom").onclick=()=>{socketEmit("room:leave");room=null;show(lobby);};
  $("copyInvite").onclick=async()=>{const url=`${location.origin}${location.pathname}?room=${room.code}`;try{await navigator.clipboard.writeText(url);toast("Invite link copied!");}catch{toast(`Room code: ${room.code}`);}};
  $("exitGame").onclick=()=>{if(practice){stopPractice();show(lobby);}else{socketEmit("room:leave");room=null;gameState=null;show(lobby);}};
  $("backToLobby").onclick=()=>{if(practice)stopPractice();else socketEmit("room:leave");room=null;gameState=null;show(lobby);};
  const dirs={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]};
  function setDirection(dx,dy){if(practice&&local){if(dx===-local.dx&&dy===-local.dy)return;local.dx=dx;local.dy=dy;}else socketEmit("game:input",{dx,dy});}
  document.addEventListener("keydown",e=>{let d=null; if(["ArrowUp","w","W"].includes(e.key))d=dirs.up;if(["ArrowDown","s","S"].includes(e.key))d=dirs.down;if(["ArrowLeft","a","A"].includes(e.key))d=dirs.left;if(["ArrowRight","d","D"].includes(e.key))d=dirs.right;if(d&&!gamePanel.classList.contains("hidden")){e.preventDefault();setDirection(...d);}});
  document.querySelectorAll("[data-dir]").forEach(b=>{const go=()=>setDirection(...dirs[b.dataset.dir]);b.addEventListener("click",go);b.addEventListener("touchstart",e=>{e.preventDefault();go();},{passive:false});});
  function makePlayer(x,y,color,playerName){return {x,y,dx:1,dy:0,trail:[],territory:[],alive:true,score:0,color,name:playerName};}
  function startPractice(){
    practice=true;room=null;localId="local";local=makePlayer(10,20,colors[0],name());for(let y=18;y<23;y++)for(let x=8;x<13;x++)local.territory.push(`${x},${y}`);
    bots=[makePlayer(29,9,colors[1],"PixelPunk"),makePlayer(30,30,colors[2],"Minty"),makePlayer(9,31,colors[3],"Dash")];
    bots.forEach((b,i)=>{for(let y=b.y-2;y<=b.y+2;y++)for(let x=b.x-2;x<=b.x+2;x++)b.territory.push(`${x},${y}`);b.dx=i%2?0:1;b.dy=i%2?1:0;});
    gameState={players:{local,...Object.fromEntries(bots.map((b,i)=>["bot"+i,b]))}};show(gamePanel);$("gameTitle").textContent="Solo practice";$("gameMode").textContent="SOLO VS BOTS";$("gameOverlay").classList.add("hidden");
    clearInterval(loop);loop=setInterval(practiceTick,145);
  }
  function stopPractice(){clearInterval(loop);loop=null;practice=false;gameState=null;local=null;bots=[];}
  function practiceTick(){
    if(!local?.alive)return;
    [local,...bots].forEach(p=>{
      if(!p.alive)return;
      if(p!==local&&Math.random()<.12){const options=[[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy])=>dx!==-p.dx||dy!==-p.dy);[p.dx,p.dy]=options[Math.floor(Math.random()*options.length)];}
      p.x=(p.x+p.dx+SIZE)%SIZE;p.y=(p.y+p.dy+SIZE)%SIZE;const key=`${p.x},${p.y}`;
      if(!owned(p,p.x,p.y)){if(p.trail.includes(key)){p.alive=false;return;}p.trail.push(key);}else if(p.trail.length){p.territory.push(...p.trail);p.score+=p.trail.length;p.trail=[];}
      [local,...bots].forEach(other=>{if(other!==p&&other.alive&&other.trail.includes(key))other.alive=false;});
    });
    gameState={players:{local,...Object.fromEntries(bots.map((b,i)=>["bot"+i,b]))}};
    const alive=[local,...bots].filter(p=>p.alive);if(!local.alive||alive.length===1){$("overlayTitle").textContent=local.alive?"You own the arena!":"Trail intercepted!";$("overlayText").textContent=local.alive?"All bots have been eliminated.":"Your exposed trail was hit. Try another run!";$("gameOverlay").classList.remove("hidden");clearInterval(loop);}
  }
  $("practiceBtn").onclick=startPractice;
  function draw(){
    ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle="#f8fafc";ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.strokeStyle="#e8edf3";ctx.lineWidth=1;for(let i=0;i<=SIZE;i++){ctx.beginPath();ctx.moveTo(i*CELL,0);ctx.lineTo(i*CELL,canvas.height);ctx.stroke();ctx.beginPath();ctx.moveTo(0,i*CELL);ctx.lineTo(canvas.width,i*CELL);ctx.stroke();}
    if(gameState?.players){const ps=Object.values(gameState.players);ps.forEach(p=>{(p.territory||[]).forEach(k=>{const [x,y]=k.split(",").map(Number);ctx.fillStyle=p.color+"b8";ctx.fillRect(x*CELL+1,y*CELL+1,CELL-2,CELL-2);});(p.trail||[]).forEach(k=>{const [x,y]=k.split(",").map(Number);ctx.fillStyle=p.color;ctx.fillRect(x*CELL+1,y*CELL+1,CELL-2,CELL-2);});if(p.alive){ctx.fillStyle=p.color;ctx.beginPath();ctx.arc((p.x+.5)*CELL,(p.y+.5)*CELL,CELL*.38,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#fff";ctx.lineWidth=2;ctx.stroke();}});
      const me=gameState.players[localId]||gameState.players.local;const total=SIZE*SIZE;const pct=me?Math.min(100,Math.round((new Set(me.territory||[]).size/total)*100)):0;$("territoryStat").textContent=pct+"%";$("scoreStat").textContent=String(me?.score||0).padStart(3,"0");$("rivalsStat").textContent=String(ps.filter(p=>p.alive&&p!==me).length);
    }
    requestAnimationFrame(draw);
  }
  draw();
  const params=new URLSearchParams(location.search);if(params.get("room"))$("roomCode").value=params.get("room").toUpperCase();
})();