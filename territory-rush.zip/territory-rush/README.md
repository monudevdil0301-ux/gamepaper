# Territory Rush

A browser-based territory-capture game with public/private rooms and a Socket.IO multiplayer server. This is an original game inspired by the broad territory-drawing genre; it does not use Paper.io branding or assets.

## Run on Windows

1. Install Node.js LTS from https://nodejs.org/
2. Extract this ZIP.
3. Open Command Prompt or PowerShell in the extracted `territory-rush` folder.
4. Run:

   ```bash
   npm install
   npm start
   ```

5. Open http://localhost:3000 in your browser.

## Multiplayer with friends

- Everyone on the same computer can test via `http://localhost:3000`.
- For other devices on the same Wi-Fi, open the host computer's local IP address with port 3000 (for example `http://192.168.1.25:3000`). Windows Firewall may ask permission.
- For friends over the internet, deploy this Node.js app to a host that supports persistent WebSocket connections, such as Render, Railway, or a VPS. Use the public URL from the host.

## Features

- Create public and private rooms, join by code, copy invitation links.
- Public room list and quick join.
- Lobby player list, ready states, and room host controls.
- Canvas arena, territory/trail visualization, keyboard and mobile controls.
- Solo practice against simple bots.
- Live territory and score panel.

## Notes

This is a starter project. Multiplayer room creation and synchronization are implemented, but online match simulation is intentionally a lightweight prototype. Before public release, add server-authoritative collision/territory rules, persistent reconnect handling, rate limiting, anti-cheat validation, and automated tests. Room matches are in-memory and reset when the server restarts.