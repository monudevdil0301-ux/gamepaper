const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
app.use(express.static("public"));

const rooms = new Map();
const COLORS = ["#6c63ff", "#ff6b6b", "#2ec4b6", "#ffb703", "#f15bb5", "#4ea8de", "#80b918", "#fb8500"];

function roomCode() { return crypto.randomBytes(3).toString("hex").toUpperCase(); }
function publicRoom(room) {
  return { code: room.code, name: room.name, isPublic: room.isPublic, players: room.players.size,
    maxPlayers: room.maxPlayers, started: room.started, hostId: room.hostId,
    members: [...room.players.values()].map(p => ({ id: p.id, name: p.name, color: p.color, ready: p.ready })) };
}
function emitRoom(room) { io.to(room.code).emit("room:update", publicRoom(room)); }
function leaveCurrent(socket) {
  const code = socket.data.roomCode;
  if (!code) return;
  const room = rooms.get(code);
  socket.leave(code);
  socket.data.roomCode = null;
  if (!room) return;
  room.players.delete(socket.id);
  if (!room.players.size) { rooms.delete(code); io.emit("rooms:list", listPublicRooms()); return; }
  if (room.hostId === socket.id) room.hostId = room.players.keys().next().value;
  emitRoom(room);
  io.emit("rooms:list", listPublicRooms());
}
function listPublicRooms() {
  return [...rooms.values()].filter(r => r.isPublic && !r.started && r.players.size < r.maxPlayers).map(publicRoom);
}
function joinRoom(socket, room, name) {
  if (room.players.size >= room.maxPlayers) return socket.emit("notice", "This room is full.");
  socket.data.roomCode = room.code;
  socket.join(room.code);
  const color = COLORS[room.players.size % COLORS.length];
  room.players.set(socket.id, { id: socket.id, name: String(name || "Player").slice(0, 18), color, ready: socket.id === room.hostId, x: 12 + room.players.size * 4, y: 12 });
  socket.emit("room:joined", publicRoom(room));
  emitRoom(room);
  io.emit("rooms:list", listPublicRooms());
}
io.on("connection", socket => {
  socket.emit("rooms:list", listPublicRooms());
  socket.on("rooms:refresh", () => socket.emit("rooms:list", listPublicRooms()));
  socket.on("room:create", ({ name, isPublic, roomName } = {}) => {
    leaveCurrent(socket);
    let code = roomCode();
    while (rooms.has(code)) code = roomCode();
    const room = { code, name: String(roomName || "Territory Arena").slice(0, 30), isPublic: !!isPublic, maxPlayers: 8, players: new Map(), hostId: socket.id, started: false, state: null };
    rooms.set(code, room);
    joinRoom(socket, room, name);
  });
  socket.on("room:join", ({ code, name } = {}) => {
    leaveCurrent(socket);
    const room = rooms.get(String(code || "").trim().toUpperCase());
    if (!room) return socket.emit("notice", "Room not found. Check the code and try again.");
    if (room.started) return socket.emit("notice", "That match has already started.");
    joinRoom(socket, room, name);
  });
  socket.on("room:quick-join", ({ name } = {}) => {
    leaveCurrent(socket);
    const room = [...rooms.values()].find(r => r.isPublic && !r.started && r.players.size < r.maxPlayers);
    if (room) return joinRoom(socket, room, name);
    socket.emit("notice", "No public rooms available. Create one to get started.");
  });
  socket.on("room:leave", () => leaveCurrent(socket));
  socket.on("room:ready", value => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || !room.players.has(socket.id)) return;
    room.players.get(socket.id).ready = !!value;
    emitRoom(room);
  });
  socket.on("room:start", () => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.hostId !== socket.id) return;
    if (room.players.size < 1) return;
    room.started = true;
    room.state = { startedAt: Date.now(), players: {} };
    for (const p of room.players.values()) room.state.players[p.id] = { x: 8 + Math.floor(Math.random()*20), y: 8 + Math.floor(Math.random()*20), dx: 1, dy: 0, trail: [], territory: [], alive: true, score: 0, color: p.color, name: p.name };
    io.to(room.code).emit("game:start", { room: publicRoom(room), state: room.state });
    io.emit("rooms:list", listPublicRooms());
  });
  socket.on("game:input", ({ dx, dy } = {}) => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || !room.started || !room.state || !room.state.players[socket.id]) return;
    const p = room.state.players[socket.id];
    if (Math.abs(dx || 0) + Math.abs(dy || 0) !== 1) return;
    if (dx === -p.dx && dy === -p.dy) return;
    p.dx = dx; p.dy = dy;
  });
  socket.on("disconnect", () => leaveCurrent(socket));
});

// Lightweight authoritative movement loop for online room matches.
setInterval(() => {
  for (const room of rooms.values()) {
    if (!room.started || !room.state) continue;
    const state = room.state;
    const size = 40;
    for (const [id, p] of Object.entries(state.players)) {
      if (!p.alive) continue;
      p.x = (p.x + p.dx + size) % size;
      p.y = (p.y + p.dy + size) % size;
      const key = `${p.x},${p.y}`;
      const owned = p.territory.includes(key);
      if (!owned) {
        if (p.trail.includes(key)) { p.alive = false; continue; }
        p.trail.push(key);
      } else if (p.trail.length) {
        p.territory.push(...p.trail);
        p.score += p.trail.length;
        p.trail = [];
      }
      for (const [otherId, other] of Object.entries(state.players)) {
        if (otherId !== id && other.alive && other.trail.includes(key)) other.alive = false;
      }
    }
    io.to(room.code).emit("game:state", state);
    if (Object.values(state.players).filter(p => p.alive).length <= 1) {
      room.started = false;
      io.to(room.code).emit("game:over", state);
      emitRoom(room);
      io.emit("rooms:list", listPublicRooms());
    }
  }
}, 180);

server.listen(PORT, () => console.log(`Territory Rush running at http://localhost:${PORT}`));